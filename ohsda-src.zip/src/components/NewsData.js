import service1 from "../assets/images/service1.jfif";
import service2 from "../assets/images/service2.jfif";
import service3 from "../assets/images/service3.jfif";
const sd = [
  {
    id: 1,
    title: "",
    info: "5000 families recevied winterization support",
    image: service1,
    action: "Read more",
  },
  {
    id: 2,
    title: "FSAC",
    info: "1963 Households received non-food items NFI",
    image: service2,
    action: "Read more",
  },
  {
    id: 1,
    title: "Empowerment",
    info: "200 People learned local business development",
    image: service3,
    action: "Read More",
  },
];
export default sd;
